lab1
====

.. toctree::
   :maxdepth: 4

   Graph
   GraphTests
   UI
